
// This file is no longer used as the project has been converted to static HTML/CSS/JS.
// Keeping this file empty prevents the "Could not find root element" error if the build system still tries to load it.
console.log("Portfolio loaded in static mode.");
